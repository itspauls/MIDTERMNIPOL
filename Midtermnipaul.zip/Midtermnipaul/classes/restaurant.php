<?php 

include('order.php');

class Restaurants extends Orders{
    function order_item(){
        echo 1;
    }
}


?>